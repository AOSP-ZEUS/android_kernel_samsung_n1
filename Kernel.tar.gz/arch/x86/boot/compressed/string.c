#include "misc.h"
#include "../string.c"
