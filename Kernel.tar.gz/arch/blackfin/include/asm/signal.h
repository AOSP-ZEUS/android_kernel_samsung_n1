#ifndef _BLACKFIN_SIGNAL_H
#define _BLACKFIN_SIGNAL_H

#define SA_RESTORER 0x04000000
#include <asm-generic/signal.h>

#endif
