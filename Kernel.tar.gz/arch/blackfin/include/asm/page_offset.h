/*
 * This handles the memory map
 *
 * Copyright 2004-2008 Analog Devices Inc.
 *
 * Licensed under the GPL-2 or later.
 */

#ifdef CONFIG_BLACKFIN
#define PAGE_OFFSET_RAW		0x00000000
#endif
