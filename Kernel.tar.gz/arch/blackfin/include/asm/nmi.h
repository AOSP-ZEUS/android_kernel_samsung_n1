/*
 * Copyright 2010 Analog Devices Inc.
 *
 * Licensed under the GPL-2
 */

#ifndef _BFIN_NMI_H_
#define _BFIN_NMI_H_

#include <linux/nmi.h>

#endif
