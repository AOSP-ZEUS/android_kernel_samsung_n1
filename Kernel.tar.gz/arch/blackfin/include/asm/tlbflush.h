#include <asm-generic/tlbflush.h>
#define flush_tlb_kernel_range(s, e) do { } while (0)
