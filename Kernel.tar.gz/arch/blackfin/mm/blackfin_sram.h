/*
 * Local prototypes meant for internal use only
 *
 * Copyright 2006-2009 Analog Devices Inc.
 *
 * Licensed under the GPL-2 or later.
 */

#ifndef __BLACKFIN_SRAM_H__
#define __BLACKFIN_SRAM_H__

extern void *l1sram_alloc(size_t);

#endif
